# The Skeptical Researcher: AI Research Assistant

A multi-agent AI system for robust research report generation with built-in skepticism, debate, and transparency.

## 🎯 Key Novelties

1. **🧠 Skeptical Academic Personality** - Agents maintain academic skepticism and critical evaluation
2. **⚔️ Multi-Agent Debate System** - Pro/Con agents debate controversial claims with impartial resolution  
3. **🔍 Source Transparency Matrix** - Comprehensive evaluation of evidence quality and confidence scoring

## 🚀 Quick Start

1. **Install dependencies:**
   ```bash
   pip install -r requirements.txt