from .chief_researcher import ChiefResearcher
from .search_agents import SearchAgents
from .debate_agents import DebateAgents
from .synthesis_evaluator import SynthesisEvaluator

class ResearchAgents:
    """Container for all research agents"""
    
    def __init__(self, llm, search_manager):
        self.chief_researcher = ChiefResearcher(llm)
        self.search_agents = SearchAgents(llm, search_manager)
        self.debate_agents = DebateAgents(llm)
        self.synthesis_evaluator = SynthesisEvaluator(llm)