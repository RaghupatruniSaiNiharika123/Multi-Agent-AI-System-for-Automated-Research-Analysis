import json #Analyzes research queries 
import logging #For execution tracking and debugging
from langchain_core.messages import HumanMessage, SystemMessage
#For proper LLM communication format

logger = logging.getLogger(__name__)

class ChiefResearcher: #Analyzes research queries 
    """Novelty 1: Skeptical Academic Personality"""
    
    def __init__(self, llm):
        self.llm = llm
    
    def analyze_query(self, state):
        """Break down query and create research plan with academic skepticism"""
        logger.info("🧠 Chief Researcher analyzing query...")
        
        system_prompt = """You are a skeptical academic researcher with 20 years of experience. Your role is to:
        1. Break down complex queries into researchable components with academic rigor
        2. Identify potential controversies, methodological limitations, and points of debate
        3. Prioritize primary sources, peer-reviewed research, and empirical evidence
        4. Actively look for conflicting evidence, publication biases, and methodological flaws
        5. Maintain balance between healthy skepticism and open-minded inquiry

        Approach: Be thorough, critical, evidence-based, and always consider alternative explanations."""
        
        user_prompt = f"""
        Analyze this research query with academic skepticism:

        QUERY: {state.original_query}

        Provide a comprehensive research plan with:
        1. Key claims/facts that need empirical verification
        2. Potential controversies or debated aspects in the literature
        3. Specific search terms for comprehensive research across viewpoints
        4. Methodological considerations and potential biases to watch for
        5. Quality criteria for source evaluation

        Return your analysis as structured JSON with these keys:
        - research_plan: string describing the overall approach
        - key_claims: list of main claims to verify
        - potential_controversies: list of debatable aspects
        - search_terms: list of specific search queries
        - methodological_considerations: list of research quality factors
        - skepticism_framework: list of critical evaluation criteria
        """
        
        messages = [
            SystemMessage(content=system_prompt),
            HumanMessage(content=user_prompt)
        ]
        
        try: 
        #USER QUERY → SYSTEM PROMPT → LLM PROCESSING → JSON OUTPUT → PARSING → STATE UPDATE
            response = self.llm.invoke(messages) #LLM API Call
            analysis = json.loads(response.content) #JSON Parsing
        except Exception as e:
            logger.warning(f"JSON parsing failed, using fallback analysis: {e}")
            analysis = self._create_fallback_analysis(state.original_query)
        
        #State Updates & Metrics Tracking
        state.search_results["research_plan"] = analysis ## 💾 Store analysis
        state.research_metrics["analysis_completed"] = True
        state.research_metrics["controversies_identified"] = len(analysis.get('potential_controversies', []))
        
        logger.info(f"✅ Research plan created with {len(analysis.get('potential_controversies', []))} controversies identified")
        return state
    
    #Fallback Strategy:
    def _create_fallback_analysis(self, query: str) -> dict:
        """Create fallback analysis when LLM fails"""
        return {
            "research_plan": f"Comprehensive skeptical analysis of {query}",
            "key_claims": [
                f"Main impacts and effects of the topic in {query}",
                f"Methodological considerations for studying {query}",
                f"Ethical and practical implications of {query}"
            ],
            "potential_controversies": [
                f"Debate about effectiveness and impact in {query}",
                f"Ethical concerns surrounding {query}",
                f"Methodological challenges in researching {query}"
            ],
            "search_terms": [
                f"{query} study research",
                f"{query} impact effects",
                f"{query} controversy debate",
                f"{query} methodological analysis"
            ],
            "methodological_considerations": [
                "Study sample sizes and representativeness",
                "Research design quality and controls",
                "Publication bias and selective reporting",
                "Long-term vs short-term impacts"
            ],
            "skepticism_framework": [
                "Source credibility and author credentials",
                "Methodological rigor and transparency",
                "Conflict of interest declarations",
                "Replication and validation status"
            ]
        }
    
# # What happens inside Groq LLM:
# input_tokens = tokenize(messages)  # Convert text to numerical tokens
# # Example: "skeptical" → [12345, 67890, ...]
# context_window = 32768  # Mixtral 8x7B context size

"""
Chain of Thought Processing Inside LLM
Internal Reasoning Steps:

Query Analysis: "What is the user really asking about {query}?"

Domain Mapping: "What academic field does this belong to?"

Controversy Detection: "Where do experts disagree about this topic?"

Research Planning: "How would a skeptical researcher approach this?"

Bias Anticipation: "What methodological pitfalls should we watch for?"

Search Strategy: "What terms will find balanced perspectives?"

JSON Structuring: "How to format this analysis as requested JSON?"

D. JSON Generation Process
The LLM constructs the response following strict JSON schema: """