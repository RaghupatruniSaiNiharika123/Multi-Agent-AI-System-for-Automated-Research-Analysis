import json
import logging
from typing import List, Dict
from langchain_core.messages import HumanMessage

logger = logging.getLogger(__name__)

class DebateAgents:
    """Novelty 2: Multi-Agent Debate System"""
    
    def __init__(self, llm):
        self.llm = llm
    
    def coordinate_debates(self, state):
        """Coordinate multi-agent debate for controversial claims"""
        logger.info("⚔️ Debate coordinator assessing controversies...")
        
        controversial_claims = state.search_results["research_plan"].get("potential_controversies", [])
        
        if not state.processed_claims:
            state.processed_claims = []
        
        # Find next unprocessed controversial claim
        unprocessed_claims = [claim for claim in controversial_claims if claim not in state.processed_claims]
        
        if unprocessed_claims and not state.current_claim:
            # Start debate on next claim
            state.current_claim = unprocessed_claims[0]
            state.debated_claims[state.current_claim] = {
                "pro_arguments": [],
                "con_arguments": [],
                "resolution": "",
                "sources_used": [],
                "debate_round": 1
            }
            logger.info(f"🎯 Starting debate on: {state.current_claim}")
        
        elif state.current_claim and state.debated_claims[state.current_claim]["pro_arguments"]:
            # Debate completed, resolve it
            state.debated_claims[state.current_claim]["resolution"] = self._resolve_debate(
                state.current_claim,
                state.debated_claims[state.current_claim]["pro_arguments"],
                state.debated_claims[state.current_claim]["con_arguments"]
            )
            state.processed_claims.append(state.current_claim)
            state.research_metrics["debates_completed"] = len(state.processed_claims)
            logger.info(f"✅ Debate resolved for: {state.current_claim}")
            state.current_claim = None
        
        return state
    
    def pro_agent(self, state):
        """Pro debate agent - finds supporting evidence"""
        if not state.current_claim:
            return state
            
        logger.info(f"👍 Pro agent building case for: {state.current_claim}")
        
        prompt = f"""
        As a PRO advocate, find the strongest supporting evidence for this claim:
        CLAIM: {state.current_claim}

        Available credible sources: {json.dumps([s for s in state.search_results['evaluated_results'] if s['should_use']], indent=2)}

        Your role: Build the most compelling case SUPPORTING this claim.
        - Find specific evidence from the most credible sources
        - Highlight methodological strengths and empirical support
        - Emphasize positive implications and supporting data
        - Address potential counter-arguments proactively
        - Reference specific sources and their credibility scores

        Provide 2-3 well-reasoned arguments with specific evidence citations.

        Return as JSON: {{"arguments": [{{"point": "...", "evidence": "...", "source": "...", "strength": "high/medium/low"}}]}}
        """
        
        try:
            response = self.llm.invoke([HumanMessage(content=prompt)])
            pro_arguments = json.loads(response.content)
            state.debated_claims[state.current_claim]["pro_arguments"] = pro_arguments["arguments"]
        except Exception as e:
            logger.warning(f"Pro agent failed, using fallback: {e}")
            state.debated_claims[state.current_claim]["pro_arguments"] = self._create_fallback_pro_arguments(state.current_claim)
        
        logger.info(f"✅ Pro agent prepared {len(state.debated_claims[state.current_claim]['pro_arguments'])} arguments")
        return state
    
    def con_agent(self, state):
        """Con debate agent - finds counter-evidence and limitations"""
        if not state.current_claim:
            return state
            
        logger.info(f"👎 Con agent building case against: {state.current_claim}")
        
        prompt = f"""
        As a CON skeptic, find the strongest counter-evidence and limitations for this claim:
        CLAIM: {state.current_claim}

        Available credible sources: {json.dumps([s for s in state.search_results['evaluated_results'] if s['should_use']], indent=2)}

        Your role: Build the most compelling case CHALLENGING this claim.
        - Find specific counter-evidence from credible sources
        - Highlight methodological limitations and flaws
        - Identify potential biases and confounding factors
        - Emphasize contradictory findings and alternative explanations
        - Reference specific sources and their credibility scores

        Provide 2-3 well-reasoned counter-arguments with specific evidence citations.

        Return as JSON: {{"arguments": [{{"point": "...", "evidence": "...", "source": "...", "strength": "high/medium/low"}}]}}
        """
        
        try:
            response = self.llm.invoke([HumanMessage(content=prompt)])
            con_arguments = json.loads(response.content)
            state.debated_claims[state.current_claim]["con_arguments"] = con_arguments["arguments"]
        except Exception as e:
            logger.warning(f"Con agent failed, using fallback: {e}")
            state.debated_claims[state.current_claim]["con_arguments"] = self._create_fallback_con_arguments(state.current_claim)
        
        logger.info(f"✅ Con agent prepared {len(state.debated_claims[state.current_claim]['con_arguments'])} counter-arguments")
        return state
    
    def _resolve_debate(self, claim: str, pro_args: List, con_args: List) -> str:
        """Resolve a debate and provide balanced conclusion"""
        prompt = f"""
        As an impartial academic judge with expertise in research methodology, resolve this debate:

        CLAIM: {claim}

        PRO Arguments (Supporting):
        {json.dumps(pro_args, indent=2)}

        CON Arguments (Challenging):
        {json.dumps(con_args, indent=2)}

        Provide an evidence-based resolution that:
        1. Acknowledges the strongest points from both sides
        2. Weights the evidence quality and methodological rigor
        3. Provides a nuanced, balanced conclusion
        4. Identifies areas where evidence is strongest/weakest
        5. Suggests specific areas needing more research

        Maintain academic tone and focus on empirical evidence.
        Be concise but comprehensive (200-300 words).
        """
        
        try:
            response = self.llm.invoke([HumanMessage(content=prompt)])
            return response.content
        except Exception as e:
            logger.warning(f"Debate resolution failed: {e}")
            return "Balanced analysis indicates mixed evidence with need for further research."
    
    def _create_fallback_pro_arguments(self, claim: str) -> List[Dict]:
        """Create fallback pro arguments"""
        return [
            {
                "point": "Evidence supports positive impact",
                "evidence": "Multiple studies indicate beneficial effects with proper implementation",
                "source": "Academic literature review",
                "strength": "medium"
            }
        ]
    
    def _create_fallback_con_arguments(self, claim: str) -> List[Dict]:
        """Create fallback con arguments"""
        return [
            {
                "point": "Significant limitations and risks identified",
                "evidence": "Research highlights important caveats and potential negative consequences",
                "source": "Critical studies analysis",
                "strength": "medium"
            }
        ]