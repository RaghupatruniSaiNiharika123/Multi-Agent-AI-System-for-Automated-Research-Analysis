import logging
from typing import List, Dict
from langchain_core.messages import HumanMessage

logger = logging.getLogger(__name__)

class SearchAgents:
    """Manages search operations and source evaluation"""
    
    def __init__(self, llm, search_manager):
        self.llm = llm
        self.search_manager = search_manager
    
    def conduct_research(self, state):
        """Perform skeptical research with enhanced credibility assessment"""
        logger.info("🔍 Search agents gathering sources...")
        
        search_terms = state.search_results["research_plan"].get("search_terms", 
                      [state.original_query + " research", state.original_query + " study"])
        
        # Get search results
        raw_results = self.search_manager.simulate_search(search_terms)
        
        # Apply enhanced credibility assessment and skepticism
        evaluated_results = []
        for source in raw_results:
            enhanced_source = self.search_manager.assess_source_credibility(source)
            enhanced_source["skepticism_notes"] = self.search_manager.generate_skepticism_notes(enhanced_source, self.llm)
            enhanced_source["should_use"] = enhanced_source["enhanced_credibility"] >= 6.0
            evaluated_results.append(enhanced_source)
        
        # Sort by credibility
        evaluated_results.sort(key=lambda x: x["enhanced_credibility"], reverse=True)
        
        state.search_results["raw_results"] = raw_results
        state.search_results["evaluated_results"] = evaluated_results
        state.research_metrics["sources_found"] = len(evaluated_results)
        state.research_metrics["credible_sources"] = len([s for s in evaluated_results if s['should_use']])
        
        logger.info(f"✅ Found {len(evaluated_results)} sources, {state.research_metrics['credible_sources']} credible")
        return state