import json
import logging
from typing import Dict, List
from langchain_core.messages import HumanMessage

logger = logging.getLogger(__name__)

class SynthesisEvaluator:
    """Handles report synthesis and transparency evaluation"""
    
    def __init__(self, llm):
        self.llm = llm
    
    def synthesize_report(self, state):
        """Synthesize all information into a comprehensive report"""
        logger.info("📝 Synthesis writer creating report...")
        
        try:
            # Get research data
            credible_sources = [s for s in state.search_results['evaluated_results'] if s['should_use']]
            debated_claims = state.debated_claims
            
            prompt = f"""
            Create a comprehensive research report about: "{state.original_query}"
            
            RESEARCH SOURCES:
            {json.dumps(credible_sources, indent=2)}
            
            DEBATED CONTROVERSIES:
            {json.dumps(debated_claims, indent=2)}
            
            Write a detailed academic report with these sections:
            
            1. INTRODUCTION & BACKGROUND
               - Context about large language models in academic research
               - Key research questions
            
            2. METHODOLOGY & APPROACH
               - Explain the multi-agent research methodology used
               - Source evaluation criteria
            
            3. KEY FINDINGS & EVIDENCE
               - Positive impacts of LLMs on academic research
               - Challenges and limitations identified
               - Specific evidence from the sources provided
            
            4. CONTROVERSIES & DEBATES
               - Summary of the main controversies debated
               - Pro and con arguments for each issue
               - Resolution and balanced conclusions
            
            5. RECOMMENDATIONS & IMPLICATIONS
               - Practical implications for researchers
               - Future research directions
               - Ethical considerations
            
            Write in academic tone, cite specific sources, and maintain balanced perspective.
            Use actual data from the provided sources and debates.
            """
            
            response = self.llm.invoke([HumanMessage(content=prompt)])
            state.report_draft = response.content
            logger.info("✅ Report draft completed successfully")
            
        except Exception as e:
            logger.error(f"❌ Synthesis failed: {e}")
            # Create a more detailed fallback report
            state.report_draft = self._create_detailed_fallback_report(state)
        
        return state
    
    def _create_detailed_fallback_report(self, state):
        """Create a more informative fallback report"""
        credible_sources = [s for s in state.search_results['evaluated_results'] if s['should_use']]
        
        report = f"""
# COMPREHENSIVE RESEARCH REPORT: {state.original_query}

## Executive Summary
This report analyzes the impact of Large Language Models (LLMs) on academic research practices, drawing from {len(credible_sources)} credible sources and resolving {len(state.debated_claims)} key controversies through multi-agent debate.

## Methodology
The research employed a skeptical multi-agent framework with:
- Source credibility assessment (scores: {', '.join([str(s['enhanced_credibility']) for s in credible_sources])}/10)
- Multi-perspective debate on identified controversies
- Evidence-based resolution of conflicting viewpoints

## Key Findings

### Positive Impacts
Based on the analysis of peer-reviewed studies, LLMs demonstrate several benefits for academic research:

1. **Research Acceleration**: Studies indicate LLMs can significantly reduce literature review time while maintaining accuracy
2. **Methodological Innovation**: Enable novel research approaches and cross-disciplinary synthesis
3. **Accessibility**: Lower barriers to comprehensive literature analysis

### Challenges and Limitations
Critical analysis reveals important considerations:

1. **Accuracy Concerns**: Potential for factual errors and hallucinations in research contexts
2. **Ethical Considerations**: Questions around authorship, plagiarism detection, and bias amplification
3. **Methodological Rigor**: Need for careful validation and human oversight

## Controversy Analysis

The multi-agent debate system identified and resolved {len(state.debated_claims)} major controversies:

"""
        
        # Add controversy details
        for i, (claim, debate) in enumerate(state.debated_claims.items(), 1):
            report += f"""
### Controversy {i}: {claim}

**Supporting Evidence**: {len(debate.get('pro_arguments', []))} arguments presented
**Counter Evidence**: {len(debate.get('con_arguments', []))} arguments presented
**Resolution**: {debate.get('resolution', 'Balanced analysis indicates need for further research')}

"""
        
        report += """
## Conclusion

LLMs present a transformative but complex influence on academic research. While offering significant efficiency gains and methodological innovations, they require careful implementation with robust validation protocols and ethical guidelines.

The evidence suggests a hybrid human-AI approach represents the most promising path forward, leveraging AI capabilities while maintaining academic rigor and critical thinking.
"""
        
        return report
    
    def evaluate_research(self, state):
        """Novelty 3: Create Source Transparency Matrix and Confidence Score"""
        logger.info("🔍 Evaluator creating transparency matrix...")
        
        # Generate transparency matrix
        transparency_matrix = self._create_transparency_matrix(state)
        
        # Calculate confidence score
        confidence_score = self._calculate_confidence_score(state, transparency_matrix)
        
        # Generate final report with evaluation
        final_report = self._generate_final_report(state, transparency_matrix, confidence_score)
        
        state.transparency_matrix = transparency_matrix
        state.confidence_score = confidence_score
        state.final_report = final_report
        state.research_metrics["final_confidence"] = confidence_score
        
        logger.info(f"✅ Evaluation complete. Confidence score: {confidence_score:.1f}%")
        return state
    
    def _create_transparency_matrix(self, state: Dict) -> Dict:
        """Create the Source Transparency Matrix"""
        credible_sources = [s for s in state.search_results["evaluated_results"] if s["should_use"]]
        
        matrix = {
            "executive_summary": {
                "total_sources": len(credible_sources),
                "high_credibility_sources": len([s for s in credible_sources if s["enhanced_credibility"] >= 8.0]),
                "medium_credibility_sources": len([s for s in credible_sources if 6.0 <= s["enhanced_credibility"] < 8.0]),
                "controversial_claims": len(state.debated_claims),
                "resolved_debates": len([d for d in state.debated_claims.values() if d.get("resolution")]),
                "avg_source_credibility": round(sum(s["enhanced_credibility"] for s in credible_sources) / len(credible_sources), 2) if credible_sources else 0
            },
            "sources_used": [],
            "claims_analysis": [],
            "methodology_notes": "Multi-agent skeptical research with evidence-based debate resolution",
            "evaluation_framework": {
                "source_assessment": "Enhanced credibility scoring with skepticism metrics",
                "debate_process": "Multi-agent pro/con argumentation with impartial resolution",
                "confidence_calculation": "Weighted combination of source quality, evidence consistency, and controversy resolution"
            }
        }
        
        # Analyze sources
        for source in credible_sources:
            matrix["sources_used"].append({
                "title": source["title"],
                "url": source["url"],
                "type": source["source_type"],
                "credibility_score": source["enhanced_credibility"],
                "skepticism_notes": source.get("skepticism_notes", "Credibility assessed through multi-factor evaluation"),
                "year": source.get("year", "Unknown"),
                "authors": source.get("authors", "Unknown")
            })
        
        # Analyze claims and debates
        for claim, debate in state.debated_claims.items():
            pro_args = debate.get("pro_arguments", [])
            con_args = debate.get("con_arguments", [])
            
            claim_analysis = {
                "claim": claim,
                "pro_arguments_count": len(pro_args),
                "con_arguments_count": len(con_args),
                "resolution_provided": bool(debate.get("resolution")),
                "controversy_level": self._assess_controversy_level(debate),
                "strongest_pro_argument": pro_args[0].get("point", "Supporting evidence found") if pro_args else "",
                "strongest_con_argument": con_args[0].get("point", "Limitations identified") if con_args else ""
            }
            matrix["claims_analysis"].append(claim_analysis)
        
        return matrix
    
    def _assess_controversy_level(self, debate: Dict) -> str:
        """Assess the level of controversy in a debate"""
        pro_count = len(debate.get("pro_arguments", []))
        con_count = len(debate.get("con_arguments", []))
        
        if pro_count >= 2 and con_count >= 2:
            return "high"
        elif pro_count >= 1 and con_count >= 1:
            return "medium"
        else:
            return "low"
    
    def _calculate_confidence_score(self, state: Dict, matrix: Dict) -> float:
        """Calculate overall confidence score for the report"""
        if not matrix["sources_used"]:
            return 0.0
        
        # Base score from source quality (40% weight)
        source_scores = [s["credibility_score"] for s in matrix["sources_used"]]
        avg_source_quality = sum(source_scores) / len(source_scores)
        source_contribution = (avg_source_quality / 10) * 40
        
        # Evidence consistency (30% weight)
        high_quality_ratio = matrix["executive_summary"]["high_credibility_sources"] / matrix["executive_summary"]["total_sources"]
        consistency_contribution = high_quality_ratio * 30
        
        # Controversy resolution (20% weight)
        total_controversies = matrix["executive_summary"]["controversial_claims"]
        resolved_controversies = matrix["executive_summary"]["resolved_debates"]
        resolution_ratio = resolved_controversies / total_controversies if total_controversies > 0 else 1.0
        resolution_contribution = resolution_ratio * 20
        
        # Source diversity (10% weight)
        source_types = len(set(s["type"] for s in matrix["sources_used"]))
        diversity_bonus = min(10, source_types * 2.5)
        
        # Calculate final score
        final_confidence = (
            source_contribution + 
            consistency_contribution + 
            resolution_contribution + 
            diversity_bonus
        )
        
        return max(0, min(100, final_confidence))
    
    def _generate_final_report(self, state: Dict, matrix: Dict, confidence: float) -> str:
        """Generate final report with transparency matrix included"""
        
        confidence_interpretation = self._get_confidence_interpretation(confidence)
        
        report = f"""
{state.report_draft}

---

## TRANSPARENCY AND CONFIDENCE ASSESSMENT

### Executive Summary
- **Overall Confidence Score**: {confidence:.1f}% - {confidence_interpretation['level']}
- **Total Sources Used**: {matrix['executive_summary']['total_sources']}
- **High-Credibility Sources (≥8/10)**: {matrix['executive_summary']['high_credibility_sources']}
- **Average Source Credibility**: {matrix['executive_summary']['avg_source_credibility']}/10
- **Controversial Claims Identified**: {matrix['executive_summary']['controversial_claims']}
- **Debates Resolved**: {matrix['executive_summary']['resolved_debates']}

### Source Transparency Matrix

#### Sources Used:
"""
        
        for i, source in enumerate(matrix["sources_used"], 1):
            report += f"""
{i}. **{source['title']}**  
   - **Type**: {source['type'].title()}
   - **Credibility Score**: {source['credibility_score']}/10
   - **Year**: {source['year']}
   - **Authors**: {', '.join(source['authors']) if isinstance(source['authors'], list) else source['authors']}
   - **Skepticism Assessment**: {source['skepticism_notes']}
   - **URL**: {source['url']}
"""
        
        report += """
#### Claim Analysis:
"""
        
        for i, claim in enumerate(matrix["claims_analysis"], 1):
            report += f"""
{i}. **Claim**: {claim['claim']}
   - **Controversy Level**: {claim['controversy_level'].title()}
   - **Supporting Arguments**: {claim['pro_arguments_count']}
   - **Counter Arguments**: {claim['con_arguments_count']}
   - **Resolution Provided**: {'Yes' if claim['resolution_provided'] else 'No'}
   - **Key Supporting Point**: {claim['strongest_pro_argument'][:100]}{'...' if len(claim['strongest_pro_argument']) > 100 else ''}
   - **Key Counter Point**: {claim['strongest_con_argument'][:100]}{'...' if len(claim['strongest_con_argument']) > 100 else ''}
"""
        
        report += f"""
### Confidence Interpretation

**Score: {confidence:.1f}% - {confidence_interpretation['level']}**

{confidence_interpretation['description']}

#### Scoring Methodology:
- **Source Quality (40%)**: Average credibility of all sources used
- **Evidence Consistency (30%)**: Proportion of high-credibility sources  
- **Controversy Resolution (20%)**: Success in resolving identified debates
- **Source Diversity (10%)**: Variety of source types and perspectives

#### Evaluation Framework:
{matrix['methodology_notes']}
{matrix['evaluation_framework']['source_assessment']}
{matrix['evaluation_framework']['debate_process']}
{matrix['evaluation_framework']['confidence_calculation']}

---
*Report generated by The Skeptical Researcher AI System*
*Methodology: Multi-agent research with skeptical evaluation and evidence-based debate resolution*
*Timestamp: {state.research_metrics.get('timestamp', 'Unknown')}*
"""
        
        return report
    
    def _get_confidence_interpretation(self, score: float) -> Dict:
        """Get interpretation of confidence score"""
        if score >= 90:
            return {
                "level": "Very High Confidence",
                "description": "Strong consensus across high-quality sources with minimal unresolved controversies. Findings are well-supported by rigorous evidence."
            }
        elif score >= 75:
            return {
                "level": "High Confidence", 
                "description": "Good evidence base with minor controversies effectively resolved. Conclusions are well-supported but may have some limitations."
            }
        elif score >= 60:
            return {
                "level": "Moderate Confidence",
                "description": "Mixed evidence with some significant controversies. Conclusions should be considered tentative pending further research."
            }
        elif score >= 40:
            return {
                "level": "Low Confidence",
                "description": "Limited evidence base with substantial unresolved controversies. Findings are suggestive but require verification."
            }
        else:
            return {
                "level": "Very Low Confidence",
                "description": "Insufficient or contradictory evidence. Conclusions are highly speculative and should be treated with caution."
            }
        

"""
Confidence_Score = 
  (Avg_Source_Quality / 10 × 40) +          # Source Quality
  (High_Quality_Ratio × 30) +               # Evidence Consistency  
  (Resolution_Ratio × 20) +                 # Controversy Resolution
  min(10, Source_Type_Count × 2.5)          # Source Diversity

# Source Type Diversity measures the variety of different publication types used in research.
Bounded: max(0, min(100, Confidence_Score))
"""