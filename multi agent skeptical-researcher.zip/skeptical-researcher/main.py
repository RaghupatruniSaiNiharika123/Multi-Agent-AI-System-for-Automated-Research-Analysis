"""
Main entry point for The Skeptical Researcher AI System
"""

import os
import json
import asyncio
import logging
import sys
import re # Added to ensure re is always available
from dotenv import load_dotenv

# --- Colorama Setup ---
# Try to import colorama, but continue without it if not available
try:
    from colorama import init, Fore, Style
    init()
    COLORAMA_AVAILABLE = True
except ImportError:
    # Create dummy color classes if colorama is not available
    class DummyColor:
        def __getattr__(self, name):
            return ''
    Fore = DummyColor()
    Style = DummyColor()
    COLORAMA_AVAILABLE = False
    print("⚠️  colorama not installed. Running without colors.")

# Load environment variables
load_dotenv()

# --- Project Modules Import ---
# Import all essential project modules at the top level
try:
    from utils.config import Config
    from utils.search_manager import SearchManager
    from agents import ResearchAgents
    from workflows.research_workflow import ResearchWorkflow
    from models.research_state import ResearchState # 💡 FIX 4 & 5: Import ResearchState here
    MODULES_AVAILABLE = True
except ImportError as e:
    print(f"❌ Missing dependencies: {e}")
    print("Please install required packages: pip install -r requirements.txt")
    # 💡 FIX 2 & 7: Set to False only if import fails
    MODULES_AVAILABLE = False
    # If a critical import fails, we must exit or raise immediately
    sys.exit(1) # Terminate if critical modules are missing

# 💡 FIX 3: Define a basic FallbackLLM that includes model_name
class FallbackLLM:
    def __init__(self):
        self.model_name = "SIMULATED_LLM_FALLBACK"
    def __call__(self, *args, **kwargs):
        raise NotImplementedError("FallbackLLM cannot be called without proper implementation.")
    def __repr__(self):
        return f"<FallbackLLM model_name='{self.model_name}'>"


class SkepticalResearcherApp:
    """Main application class"""
    
    def __init__(self):
        # 💡 FIX 1: Config is now globally imported, so this is safe
        self.setup_logging()
        self.validate_environment()
        self.initialize_components()
    
    def setup_logging(self):
        """Setup application logging"""
        # 💡 FIX 1: Use Config.LOG_LEVEL which is now available
        log_level_str = Config.LOG_LEVEL.upper() if MODULES_AVAILABLE and hasattr(Config, 'LOG_LEVEL') else 'INFO'
        
        logging.basicConfig(
            level=getattr(logging, log_level_str),
            format=f'{self.colorize("%(asctime)s", "CYAN")} - {self.colorize("%(name)s", "GREEN")} - {self.colorize("%(levelname)s", "YELLOW")} - %(message)s',
            datefmt='%H:%M:%S'
        )
        self.logger = logging.getLogger(__name__)
    
    def colorize(self, text, color):
        """Colorize text if colorama is available"""
        if not COLORAMA_AVAILABLE:
            return text
        
        color_map = {
            "RED": Fore.RED,
            "GREEN": Fore.GREEN,
            "YELLOW": Fore.YELLOW,
            "BLUE": Fore.BLUE,
            "MAGENTA": Fore.MAGENTA,
            "CYAN": Fore.CYAN,
            "RESET": Style.RESET_ALL
        }
        return f"{color_map.get(color, '')}{text}{Style.RESET_ALL}"
    
    def validate_environment(self):
        """Validate environment and configuration"""
        if not MODULES_AVAILABLE:
            self.logger.error("❌ Cannot validate environment: Required modules not loaded.")
            raise ImportError("Required modules not loaded.")
            
        try:
            Config.validate_config()
            self.logger.info("✅ Environment validation successful")
        except Exception as e:
            self.logger.error(f"❌ Environment validation failed: {e}")
            raise
    
    def initialize_components(self):
        """Initialize all system components"""
        # Ensure we only try to import if modules are available
        if not MODULES_AVAILABLE:
             self.logger.info("🔄 Falling back to simulated mode...")
             self.llm = FallbackLLM()
        else:
            # 💡 FIX: Use Groq instead of OpenAI
            try:
                from langchain_groq import ChatGroq
                
                # Initialize Groq LLM
                self.llm = ChatGroq(
                    model=Config.GROQ_MODEL,
                    temperature=0.1,
                    api_key=Config.GROQ_API_KEY
                )
                
                self.logger.info(f"✅ Groq LLM initialized: {self.llm.model_name}")
                
            except ImportError as e:
                self.logger.error(f"❌ Failed to import ChatGroq: {e}")
                self.logger.info("🔄 Falling back to simulated mode...")
                self.llm = FallbackLLM()
            except Exception as e:
                self.logger.error(f"❌ Failed to initialize ChatGroq: {e}")
                self.logger.info("🔄 Falling back to simulated mode...")
                self.llm = FallbackLLM()
        
        # Initialize managers and agents (these should handle the FallbackLLM gracefully)
        self.search_manager = SearchManager() if MODULES_AVAILABLE else None
        self.agents = ResearchAgents(self.llm, self.search_manager) if MODULES_AVAILABLE else None
        self.workflow = ResearchWorkflow(self.agents) if MODULES_AVAILABLE else None
        
        self.logger.info("✅ All components initialized successfully")
    
    def print_banner(self):
        """Print application banner"""
        # Ensure config is available for safe access
        confidence_threshold = f"{Config.CONFIDENCE_THRESHOLD}%" if MODULES_AVAILABLE and hasattr(Config, 'CONFIDENCE_THRESHOLD') else "N/A"
        
        banner = f"""
{self.colorize("╔════════════════════════════════════════════════════════════════╗", "BLUE")}
{self.colorize("║                   THE SKEPTICAL RESEARCHER                    ║", "BLUE")}
{self.colorize("║                 AI Research Assistant System                  ║", "BLUE")}
{self.colorize("╚════════════════════════════════════════════════════════════════╝", "BLUE")}

{self.colorize("Novelties:", "GREEN")}
{self.colorize("1. 🧠 Skeptical Academic Personality", "YELLOW")}
{self.colorize("2. ⚔️  Multi-Agent Debate System", "YELLOW")}  
{self.colorize("3. 🔍 Source Transparency Matrix", "YELLOW")}

{self.colorize(f"Model: {self.llm.model_name}", "CYAN")}
{self.colorize(f"Confidence Threshold: {confidence_threshold}", "CYAN")}
"""
        print(banner)
    
    async def run_research(self, query: str = None):
        """Run research workflow"""
        if not MODULES_AVAILABLE or not self.workflow:
            print(f"{self.colorize('❌ Cannot run research: Core modules or workflow are missing.', 'RED')}")
            return None
            
        if not query:
            query = input(f"{self.colorize('Enter your research query: ', 'GREEN')}")
        
        if not query.strip():
            print(f"{self.colorize('❌ Query cannot be empty', 'RED')}")
            return
        
        try:
            # Execute research
            results = await self.workflow.execute_research(query)
            
            # Handle the case where results might be a dict
            if isinstance(results, dict):
                print("⚠️  Results returned as dictionary, converting...")
                # 💡 FIX 4 & 5: ResearchState is now imported at the top level
                results = ResearchState(**results)
            
            if results and hasattr(results, 'confidence_score'):
                # Display results
                self.display_results(results)
                
                # Save results
                self.save_results(results, query)
                
                return results
            else:
                print(f"{self.colorize('❌ Research completed but results are invalid', 'RED')}")
                if results:
                    # Provide a cleaner error message
                    print(f"Results type: {type(results)}")
                    print(f"Missing required attribute 'confidence_score'")
                return None
                
        except Exception as e:
            self.logger.error(f"Research failed: {e}")
            print(f"{self.colorize(f'❌ Research failed: {e}', 'RED')}")
            # 💡 FIX 8: Removed full traceback for cleaner user output
            return None
    
    def display_results(self, results):
        """Display research results"""
        print(f"\n{self.colorize('='*80, 'GREEN')}")
        print(f"{self.colorize('📊 RESEARCH RESULTS', 'GREEN')}")
        print(f"{self.colorize('='*80, 'GREEN')}")
        
        # Safely access attributes whether it's a ResearchState object or dict
        if hasattr(results, 'final_report'):
            final_report = results.final_report
            confidence_score = results.confidence_score
            research_metrics = results.research_metrics
        else:
            # Use .get() for safe dictionary access
            final_report = results.get('final_report', '')
            confidence_score = results.get('confidence_score', 0.0)
            research_metrics = results.get('research_metrics', {})
        
        print(f"{self.colorize('Final Report:', 'CYAN')}")
        print(final_report)
        
        # 💡 Fix: Cleaned up spacing and ensured consistent .get() usage
        print(f"\n{self.colorize('📈 KEY METRICS:', 'YELLOW')}")
        
        # Use 3 spaces for consistent indentation across the metrics
        print(f"   • {self.colorize(f'Confidence Score: {confidence_score:.1f}%', 'GREEN')}")
        print(f"   • {self.colorize(f'Credible Sources: {research_metrics.get('credible_sources', 0)}', 'BLUE')}")
        print(f"   • {self.colorize(f'Debates Completed: {research_metrics.get('debates_completed', 0)}', 'MAGENTA')}")
        print(f"   • {self.colorize(f'Total Controversies: {research_metrics.get('controversies_identified', 0)}', 'CYAN')}")
    
    def save_results(self, results, query: str):
        """Save research results to files"""
        if not MODULES_AVAILABLE:
            print(f"{self.colorize('⚠️ Cannot save results: Core modules are missing.', 'YELLOW')}")
            return
            
        # Create outputs directory if it doesn't exist
        os.makedirs("outputs/reports", exist_ok=True)
        os.makedirs("outputs/data", exist_ok=True)
        
        # Generate filename based on query
        # re module is now imported at the top level
        safe_query = re.sub(r'[^\w\s-]', '', query.lower())
        safe_query = re.sub(r'[-\s]+', '_', safe_query)
        filename_base = f"research_{safe_query[:50]}"
        
        # Safely access attributes
        if hasattr(results, 'final_report'):
            final_report = results.final_report
            confidence_score = results.confidence_score
            transparency_matrix = results.transparency_matrix
            debated_claims = results.debated_claims
            research_metrics = results.research_metrics
            search_results = results.search_results
        else:
            final_report = results.get('final_report', '')
            confidence_score = results.get('confidence_score', 0.0)
            transparency_matrix = results.get('transparency_matrix', {})
            debated_claims = results.get('debated_claims', {})
            research_metrics = results.get('research_metrics', {})
            search_results = results.get('search_results', {})
        
        # Save report
        report_path = f"outputs/reports/{filename_base}.md"
        with open(report_path, "w", encoding="utf-8") as f:
            f.write(final_report)
        
        # Save data
        data_path = f"outputs/data/{filename_base}.json"
        
        # Calculate search results summary safely
        evaluated_results = search_results.get("evaluated_results", [])
        credible_sources_count = len([s for s in evaluated_results if s.get("should_use", False)])
        
        with open(data_path, "w", encoding="utf-8") as f:
            json.dump({
                "query": query,
                "confidence_score": confidence_score,
                "transparency_matrix": transparency_matrix,
                "debated_claims": debated_claims,
                "research_metrics": research_metrics,
                "search_results_summary": {
                    "total_sources": len(evaluated_results),
                    "credible_sources": credible_sources_count
                }
            }, f, indent=2, ensure_ascii=False)
        
        print(f"\n{self.colorize('💾 Results saved:', 'GREEN')}")
        print(f"   • Report: {report_path}")
        print(f"   • Data: {data_path}")
    
    async def interactive_mode(self):
        """Run in interactive mode"""
        self.print_banner()
        
        while True:
            print(f"\n{self.colorize('='*60, 'BLUE')}")
            print(f"{self.colorize('1.', 'CYAN')} Start new research")
            print(f"{self.colorize('2.', 'CYAN')} Exit")
            
            choice = input(f"\n{self.colorize('Select option (1-2): ', 'GREEN')}").strip()
            
            if choice == "1":
                await self.run_research()
            elif choice == "2":
                print(f"{self.colorize('👋 Thank you for using The Skeptical Researcher!', 'GREEN')}")
                break
            else:
                print(f"{self.colorize('❌ Invalid option', 'RED')}")

async def main():
    """Main application entry point"""
    try:
        # 💡 FIX 2 & 7: MODULES_AVAILABLE is now set correctly *before* this check
        if not MODULES_AVAILABLE:
            print("❌ Required modules not available. Exiting.")
            print("Run: pip install -r requirements.txt")
            return
        
        app = SkepticalResearcherApp()
        
        # Check if query provided as command line argument
        if len(sys.argv) > 1:
            query = " ".join(sys.argv[1:])
            await app.run_research(query)
        else:
            await app.interactive_mode()
            
    except KeyboardInterrupt:
        # 💡 FIX 9: Handle color variables gracefully in the interrupt handler
        color_start = Fore.YELLOW if COLORAMA_AVAILABLE else ''
        color_end = Style.RESET_ALL if COLORAMA_AVAILABLE else ''
        print(f"\n{color_start}⚠️  Research interrupted by user{color_end}")
    except Exception as e:
        color_start = Fore.RED if COLORAMA_AVAILABLE else ''
        color_end = Style.RESET_ALL if COLORAMA_AVAILABLE else ''
        print(f"{color_start}❌ Fatal error: {e}{color_end}")
        logging.exception("Application crashed")

if __name__ == "__main__":
    # Run the application
    asyncio.run(main())