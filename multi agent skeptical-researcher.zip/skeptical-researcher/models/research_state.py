from typing import Dict, List, Any, Optional
from pydantic import BaseModel, Field #Provides data validation
# Field: A function used to add extra validation

class ResearchState(BaseModel):
    """State container for the research workflow"""
    original_query: str
    search_results: Dict[str, Any] = Field(default_factory=dict)
    debated_claims: Dict[str, Any] = Field(default_factory=dict)
    report_draft: str = ""
    final_report: str = ""
    transparency_matrix: Dict[str, Any] = Field(default_factory=dict)
    confidence_score: float = 0.0
    current_claim: Optional[str] = None
    processed_claims: List[str] = Field(default_factory=list)
    research_metrics: Dict[str, Any] = Field(default_factory=dict)
    
    class Config:
        arbitrary_types_allowed = True




"""
It serves as:
Position: models/research_state.py - Core data model used by ALL components

Data Container: Holds all research data throughout the workflow

State Management: Tracks progress across different research stages

Structured Schema: Ensures data consistency and type safety

Workflow Coordination: Enables communication between different agents
"""