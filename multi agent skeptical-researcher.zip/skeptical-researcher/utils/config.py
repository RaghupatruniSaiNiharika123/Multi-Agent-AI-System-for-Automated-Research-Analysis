# import os
# from dotenv import load_dotenv

# load_dotenv()

# class Config:
#     """Configuration class for the application"""
    
#     # Groq Configuration
#     GROQ_API_KEY = os.getenv("GROQ_API_KEY")
#     GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
    
#     # Use Groq model as default
#     DEFAULT_MODEL = GROQ_MODEL
    
#     # Other existing configurations...
#     LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
#     CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "70.0"))
    
#     @classmethod
#     def validate_config(cls):
#         """Validate required configuration"""
#         if not cls.GROQ_API_KEY:
#             raise ValueError("GROQ_API_KEY is required in .env file")
        
#         # Add other validations as needed
#         print("✅ Groq configuration validated successfully")



# import os
# from dotenv import load_dotenv

# load_dotenv()

# class Config:
#     """Configuration class for the application"""
    
#     # Groq Configuration
#     GROQ_API_KEY = os.getenv("GROQ_API_KEY")
#     GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
    
#     # Use Groq model as default
#     DEFAULT_MODEL = GROQ_MODEL
    
#     # Other existing configurations...
#     LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
#     CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "70.0"))
    
#     @classmethod
#     def validate_config(cls):
#         """Validate required configuration"""
#         if not cls.GROQ_API_KEY:
#             raise ValueError("GROQ_API_KEY is required in .env file")
        
#         # Add other validations as needed
#         print("✅ Groq configuration validated successfully")
import os
from dotenv import load_dotenv

load_dotenv()

class Config:
    # API Keys
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    SERPER_API_KEY = os.getenv("SERPER_API_KEY")  # Make this optional
    
    # Model Configuration
    GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.1-8b-instant")
    
    #mixtral-8x7b-32768
    # Search Configuration
    MAX_SEARCH_RESULTS = int(os.getenv("MAX_SEARCH_RESULTS", "10"))
    SEARCH_TIMEOUT = int(os.getenv("SEARCH_TIMEOUT", "30"))
    ENABLE_WEB_SEARCH = os.getenv("ENABLE_WEB_SEARCH", "true").lower() == "true"
    
    # Debate Configuration
    MAX_DEBATE_ROUNDS = int(os.getenv("MAX_DEBATE_ROUNDS", "3"))
    DEBATE_TIMEOUT = int(os.getenv("DEBATE_TIMEOUT", "30"))
    CONSENSUS_THRESHOLD = float(os.getenv("CONSENSUS_THRESHOLD", "0.8"))
    # Agreement level needed to resolve debates (80%)
    
    # Research Configuration
    CONFIDENCE_THRESHOLD = float(os.getenv("CONFIDENCE_THRESHOLD", "80.0"))
    MIN_SOURCES = int(os.getenv("MIN_SOURCES", "3"))
    
    # Logging
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    
    @classmethod
    def validate_config(cls):
        """Validate that all required configuration is present"""
        required_config = [
            ("GROQ_API_KEY", cls.GROQ_API_KEY),
        ]
        
        # Only require SERPER_API_KEY if web search is enabled
        if cls.ENABLE_WEB_SEARCH and not cls.SERPER_API_KEY:
            raise ValueError("SERPER_API_KEY is required when ENABLE_WEB_SEARCH is true")
        
        missing = [name for name, value in required_config if not value]
        if missing:
            raise ValueError(f"Missing required environment variables: {', '.join(missing)}")
        
        # Warn if web search is disabled
        if not cls.ENABLE_WEB_SEARCH:
            print("⚠️  Web search is disabled. Research will use simulated search results.")