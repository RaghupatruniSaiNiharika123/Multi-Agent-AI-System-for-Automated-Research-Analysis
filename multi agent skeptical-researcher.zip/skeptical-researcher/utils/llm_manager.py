import os
import logging
import requests
from typing import Optional

logger = logging.getLogger(__name__)

class LLMManager:
    """LLM Manager with CONFIRMED WORKING models"""
    
    def __init__(self):
        self.llm = self._initialize_llm()
    
    def _initialize_llm(self):
        """Initialize with confirmed working models"""
        
        # Try providers in order
        providers = [
            self._try_groq_working,      # Groq with CONFIRMED working model
            self._try_gemini_working,    # Gemini 
            self._try_ollama_working,    # Ollama
        ]
        
        for provider in providers:
            llm = provider()
            if llm:
                return llm
        
        # Final fallback
        from utils.fallback_llm import FallbackLLM
        logger.warning("No working APIs found. Using enhanced simulated mode.")
        return FallbackLLM()
    
    def _try_groq_working(self):
        """Try Groq with CONFIRMED working models"""
        try:
            from langchain_groq import ChatGroq
            
            api_key = os.getenv("GROQ_API_KEY")
            if not api_key:
                logger.warning("GROQ_API_KEY not found")
                return None
        
            # ✅ CONFIRMED WORKING GROQ MODELS (October 2024)
            groq_models = [
                "llama-3.1-8b-instant",         # ✅ CONFIRMED WORKING
                "mixtral-8x7b-32768",           # Should work
                "gemma2-9b-it"                  # Should work
            ]
            
            for model in groq_models:
                try:
                    logger.info(f"🔄 Testing Groq model: {model}")
                    llm = ChatGroq(
                        model=model,
                        groq_api_key=api_key,
                        temperature=0.1,
                        max_tokens=2048
                    )
                    
                    test_response = llm.invoke("Hello")
                    logger.info(f"✅ Groq working with {model}")
                    return llm
                    
                except Exception as e:
                    logger.warning(f"❌ Groq {model} failed: {e}")
                    continue
                    
            return None
            
        except Exception as e:
            logger.warning(f"❌ Groq initialization failed: {e}")
            return None
    
    def _try_gemini_working(self):
        """Try Gemini with working models"""
        try:
            from langchain_google_genai import ChatGoogleGenerativeAI
            
            api_key = os.getenv("GEMINI_API_KEY")
            if not api_key:
                logger.warning("GEMINI_API_KEY not found")
                return None
            
            # Working Gemini models
            gemini_models = [
                "gemini-1.5-flash",        # Fast and free
                "gemini-1.5-pro",          # More capable
            ]
            
            for model in gemini_models:
                try:
                    logger.info(f"🔄 Testing Gemini model: {model}")
                    llm = ChatGoogleGenerativeAI(
                        model=model,
                        google_api_key=api_key,
                        temperature=0.1
                    )
                    
                    test_response = llm.invoke("Hello")
                    logger.info(f"✅ Gemini working with {model}")
                    return llm
                    
                except Exception as e:
                    logger.warning(f"❌ Gemini {model} failed: {e}")
                    continue
                    
            return None
            
        except Exception as e:
            logger.warning(f"❌ Gemini initialization failed: {e}")
            return None
    
    def _try_ollama_working(self):
        """Try Ollama"""
        try:
            # Test if Ollama is running
            try:
                response = requests.get("http://localhost:11434/api/tags", timeout=5)
                if response.status_code != 200:
                    return None
            except:
                return None
            
            from langchain_community.llms import Ollama
            
            # Ollama models
            ollama_models = [
                "llama3.1",
                "llama3", 
                "llama2",
                "mistral"
            ]
            
            for model in ollama_models:
                try:
                    logger.info(f"🔄 Testing Ollama model: {model}")
                    llm = Ollama(
                        model=model,
                        temperature=0.1,
                        num_predict=2048
                    )
                    
                    test_response = llm.invoke("Hello")
                    logger.info(f"✅ Ollama working with {model}")
                    return llm
                    
                except Exception as e:
                    logger.warning(f"❌ Ollama {model} failed: {e}")
                    continue
                    
            return None
            
        except Exception as e:
            logger.warning(f"❌ Ollama initialization failed: {e}")
            return None