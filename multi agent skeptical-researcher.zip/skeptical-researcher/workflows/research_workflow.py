import logging #For workflow execution tracking
from langgraph.graph import StateGraph, END #Advanced workflow management library from LangChain
from datetime import datetime #For timestamping research sessions

logger = logging.getLogger(__name__)

class ResearchWorkflow:
    """Orchestrates the complete research workflow"""
    
    def __init__(self, agents):
        self.agents = agents
        self.workflow = self._build_workflow()
    
    def _build_workflow(self):
        """Build the complete LangGraph workflow"""
        from models.research_state import ResearchState #Specifies the module path
        
        workflow = StateGraph(ResearchState)
        
        # Define all nodes
        workflow.add_node("chief_researcher", self.agents.chief_researcher.analyze_query)
        workflow.add_node("search_agents", self.agents.search_agents.conduct_research)
        workflow.add_node("debate_coordinator", self.agents.debate_agents.coordinate_debates)
        workflow.add_node("pro_agent", self.agents.debate_agents.pro_agent)
        workflow.add_node("con_agent", self.agents.debate_agents.con_agent)
        workflow.add_node("synthesis_writer", self.agents.synthesis_evaluator.synthesize_report)
        workflow.add_node("evaluator", self.agents.synthesis_evaluator.evaluate_research)
        
        # Define the workflow edges
        workflow.set_entry_point("chief_researcher")
        workflow.add_edge("chief_researcher", "search_agents")
        workflow.add_edge("search_agents", "debate_coordinator")
        
        # Conditional debate flow
        workflow.add_conditional_edges(
            "debate_coordinator",
            self._should_continue_debating,
            {
                "debate": "pro_agent",
                "continue": "synthesis_writer"
            }
        )
        
        workflow.add_edge("pro_agent", "con_agent")
        workflow.add_edge("con_agent", "debate_coordinator")
        workflow.add_edge("synthesis_writer", "evaluator")
        workflow.add_edge("evaluator", END)
        
        return workflow.compile()
    
    def _should_continue_debating(self, state):
        """Determine if we should continue debating or move to synthesis"""
        from utils.config import Config
        
        # Handle both ResearchState and dict objects
        if hasattr(state, 'search_results'):
            search_results = state.search_results
            processed_claims = state.processed_claims
            current_claim = state.current_claim
        else:
            search_results = state.get('search_results', {})
            processed_claims = state.get('processed_claims', [])
            current_claim = state.get('current_claim')
        
        controversial_claims = search_results.get("research_plan", {}).get("potential_controversies", [])
        
        # Check if we have unprocessed claims
        unprocessed = [claim for claim in controversial_claims if claim not in processed_claims]
        
        # Check if we've exceeded max debate rounds
        current_rounds = len(processed_claims)
        max_rounds_reached = current_rounds >= Config.MAX_DEBATE_ROUNDS
        
        if (unprocessed and not current_claim and not max_rounds_reached):
            return "debate"
        elif current_claim:
            return "debate"
        else:
            if max_rounds_reached:
                logger.info(f"📊 Reached maximum debate rounds ({Config.MAX_DEBATE_ROUNDS}), moving to synthesis")
            return "continue"
    
    async def execute_research(self, query: str):
        """Execute the complete research workflow"""
        from models.research_state import ResearchState
        
        logger.info(f"🚀 Starting skeptical research for: {query}")
        
        # Initialize state with timestamp
        initial_state = ResearchState(
            original_query=query,
            research_metrics={
                "timestamp": datetime.now().isoformat(),
                "query": query,
                "workflow_version": "1.0"
            }
        )
        
        print("=" * 70)
        print("🔍 THE SKEPTICAL RESEARCHER AI SYSTEM")
        print("=" * 70)
        print(f"Query: {query}")
        print("-" * 70)
        
        # Execute the workflow
        final_state = await self.workflow.ainvoke(initial_state)
        
        # Ensure we return a ResearchState object, not a dict
        if isinstance(final_state, dict):
            # Convert dict back to ResearchState
            final_state = ResearchState(**final_state)
        
        print("✅ RESEARCH COMPLETED!")
        print(f"📊 Final Confidence Score: {final_state.confidence_score:.1f}%")
        print(f"📚 Sources Used: {final_state.research_metrics.get('credible_sources', 0)}")
        print(f"⚔️ Debates Resolved: {final_state.research_metrics.get('debates_completed', 0)}")
        print(f"⏱️  Total Controversies: {final_state.research_metrics.get('controversies_identified', 0)}")
        print("=" * 70)
        
        return final_state